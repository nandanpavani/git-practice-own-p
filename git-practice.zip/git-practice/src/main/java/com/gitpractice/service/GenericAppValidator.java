package com.gitpractice.service;


public class GenericAppValidator {

    private GenericAppValidator() {
    }

    public static Boolean isNotNull(Object object) {
        if (object != null) {
            return Boolean.TRUE;
        } else return Boolean.FALSE;
    }

    public static Boolean isNull(Object object) {
        if (object == null) {
            return Boolean.TRUE;
        } else return Boolean.FALSE;
    }

    public static Boolean isValidContactNumber(String contact) {
        for (char c : contact.toCharArray()) {
            if (Character.isDigit(c) || c == '+' || c == '-') {           // which allows only { '0..9','+','-'}
            } else return false;
        }
        return contact.length() >= 10;
    }

//    public static Boolean isValidEmail(String email) {
//        if (email.matches(".*[A-Z].*")) {     //which doesn't allow uppercase
//            throw new InvalidDataException("Email should not contain uppercase characters.");
//        }
//        if (email.contains("@") && (email.endsWith(".com") || email.endsWith(".net"))) {
//            return true;
//        }
//        return false;
//    }

//    public static Boolean isValidPassword(String password) {
//
//        if (!(password.matches(".*\\d.*") &&                   // numerics
//                password.matches(".*[A-Z].*") &&             // uppercase
//                password.matches(".*[a-z].*") &&             // lowercase
//                password.matches(".*[^a-zA-Z0-9].*") &&        // specialCharacters
//                password.length() >= 8))
//            throw new InvalidDataException("password must contain at least one numeric one special character one upper case and one lower case and length >=8 chars");
//        return true;
//    }


//    public static boolean validateFile(MultipartFile multipartFile, String[] allowedTypes) {
//        if (multipartFile == null || multipartFile.isEmpty() || multipartFile.getOriginalFilename() == null || multipartFile.getOriginalFilename().split("\\.").length != 2) {
//            throw new NullPointerException("Please upload valid file");
//        }
//        try {
//            Tika tika = new Tika();
//            String mimeType = tika.detect(multipartFile.getBytes());
//            for (String allowedType : allowedTypes) {
//                if (mimeType != null && mimeType.equals(allowedType)) {
//                    return true;
//                }
//            }
//            throw new InvalidDataException("Given file not allowed");
//        } catch (Exception e) {
//            throw new InvalidDataException("file type not allowed");
//        }
//    }
//
//    public static boolean validateFile(MultipartFile multipartFile) {
//        if (multipartFile == null || multipartFile.isEmpty() || multipartFile.getOriginalFilename() == null || multipartFile.getOriginalFilename().split("\\.").length != 2) {
//            throw new NullPointerException("Please upload valid file");
//        }
//        return true;
//    }
//
//
//    public static boolean validatePhoneCode(String phoneCode) {
//        String sanitizedPhoneCode = phoneCode.replaceAll("\\s+", "");
//        if (sanitizedPhoneCode.startsWith("+") && sanitizedPhoneCode.substring(1).matches("\\d+")) {
//            return true;
//        }
//        return false;
//    }
}
