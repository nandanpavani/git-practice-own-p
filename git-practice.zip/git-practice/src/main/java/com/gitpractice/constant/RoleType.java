package com.gitpractice.constant;

public enum RoleType {

    EMPLOYEE,ADMIN
}
