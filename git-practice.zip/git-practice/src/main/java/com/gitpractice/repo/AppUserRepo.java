package com.gitpractice.repo;

import com.gitpractice.entity.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppUserRepo extends JpaRepository<AppUser,Long> {
    AppUser findByEmail(String userName);

    AppUser findByContactNumber(String userName);

    AppUser findByUserName(String userName);
}
