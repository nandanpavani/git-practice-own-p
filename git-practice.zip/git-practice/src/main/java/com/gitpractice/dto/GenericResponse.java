package com.gitpractice.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)

public class GenericResponse {
    private int code;
    private String status;
    private String message;
    private Object data;

    public GenericResponse(int code, String message, String status) {
        this.status = status;
        this.message = message;
        this.code = code;
    }

    public GenericResponse(int code, Object data) {
        this.code = code;
        this.data = data;
    }

    public GenericResponse(String message, int code, Object data) {
        this.message = message;
        this.code = code;
        this.data = data;
    }

    public GenericResponse(int code, String message, String status, Object data) {
        this.status = status;
        this.message = message;
        this.code = code;
        this.data = data;
    }
}
