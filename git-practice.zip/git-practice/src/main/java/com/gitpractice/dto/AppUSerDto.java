package com.gitpractice.dto;

import com.gitpractice.constant.RoleType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class AppUSerDto {
    String userName;
    String name;

    String email;

    String contactNumber;
    RoleType roleType;

    String passWord;
}
