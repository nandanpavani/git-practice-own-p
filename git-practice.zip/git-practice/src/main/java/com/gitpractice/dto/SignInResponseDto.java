package com.gitpractice.dto;

import com.gitpractice.entity.AppUser;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SignInResponseDto {

    private Long id;
    private String email;
    private String roleTypeName;
    private String firstName;
    private String token;
    private String profilePreviewUrl;


    public SignInResponseDto(AppUser appUser) {
        this.id = appUser.getId();
        this.firstName = appUser.getName();
        this.email = appUser.getEmail();
        this.roleTypeName = appUser.getRoleType().name();
    }

}