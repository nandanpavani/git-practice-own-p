package com.gitpractice.entity;


import com.gitpractice.constant.RoleType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(unique = true)
    private String userName;

    @Column(unique = true)
    private  String email;

    @Column(unique = true)
    private String contactNumber;

    private Float sal;

    @Enumerated(EnumType.STRING)
    private RoleType roleType;



}
